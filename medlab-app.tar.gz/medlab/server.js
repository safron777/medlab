const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'medlab-super-secret-key-2024';
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const TESTS_FILE = path.join(DATA_DIR, 'tests.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify([]));
if (!fs.existsSync(TESTS_FILE)) fs.writeFileSync(TESTS_FILE, JSON.stringify([]));

// Simple file-based DB helpers
const readJSON = (file) => JSON.parse(fs.readFileSync(file, 'utf-8'));
const writeJSON = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2));

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Relax CSP for fonts and CDN resources
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
    },
  },
}));

// Auth middleware
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// ── AUTH ROUTES ──────────────────────────────────────────────────────────────
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    if (!email || !password || !name) return res.status(400).json({ error: 'All fields required' });

    const users = readJSON(USERS_FILE);
    if (users.find(u => u.email === email)) return res.status(409).json({ error: 'Email already exists' });

    const hashed = await bcrypt.hash(password, 12);
    const user = { id: Date.now().toString(), email, password: hashed, name, createdAt: new Date().toISOString() };
    users.push(user);
    writeJSON(USERS_FILE, users);

    const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const users = readJSON(USERS_FILE);
    const user = users.find(u => u.email === email);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/auth/me', auth, (req, res) => {
  const users = readJSON(USERS_FILE);
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  res.json({ id: user.id, email: user.email, name: user.name });
});

// ── TESTS ROUTES ─────────────────────────────────────────────────────────────
app.get('/api/tests', auth, (req, res) => {
  const tests = readJSON(TESTS_FILE);
  const userTests = tests.filter(t => t.userId === req.user.id);
  res.json(userTests.sort((a, b) => new Date(b.date) - new Date(a.date)));
});

app.post('/api/tests', auth, (req, res) => {
  const tests = readJSON(TESTS_FILE);
  const test = {
    id: Date.now().toString(),
    userId: req.user.id,
    ...req.body,
    createdAt: new Date().toISOString()
  };
  tests.push(test);
  writeJSON(TESTS_FILE, tests);
  res.json(test);
});

app.put('/api/tests/:id', auth, (req, res) => {
  const tests = readJSON(TESTS_FILE);
  const idx = tests.findIndex(t => t.id === req.params.id && t.userId === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  tests[idx] = { ...tests[idx], ...req.body, id: req.params.id, userId: req.user.id };
  writeJSON(TESTS_FILE, tests);
  res.json(tests[idx]);
});

app.delete('/api/tests/:id', auth, (req, res) => {
  const tests = readJSON(TESTS_FILE);
  const filtered = tests.filter(t => !(t.id === req.params.id && t.userId === req.user.id));
  writeJSON(TESTS_FILE, filtered);
  res.json({ success: true });
});

// Get parameter history for charting
app.get('/api/tests/parameter/:name', auth, (req, res) => {
  const tests = readJSON(TESTS_FILE);
  const userTests = tests.filter(t => t.userId === req.user.id);
  const history = [];
  for (const test of userTests) {
    const param = test.parameters?.find(p => p.name === req.params.name);
    if (param) history.push({ date: test.date, value: param.value, unit: param.unit });
  }
  res.json(history.sort((a, b) => new Date(a.date) - new Date(b.date)));
});

// Serve SPA for all non-API routes
app.get('/{*path}', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log(`MedLab running on http://localhost:${PORT}`));

'use strict';

// ══════════════════════════════════════════════════════
// CONFIG & STATE
// ══════════════════════════════════════════════════════
const API = '';  // Same origin
let token = localStorage.getItem('medlab_token');
let currentUser = null;
let tests = [];
let currentCategory = 'all';
let editingTestId = null;
let paramRowCount = 0;
const charts = {};

const CATEGORIES = {
  blood: { label: 'Кровь', icon: '🩸' },
  urine: { label: 'Моча', icon: '🔬' },
  biochem: { label: 'Биохимия', icon: '⚗️' },
  hormones: { label: 'Гормоны', icon: '🧬' },
  vitamins: { label: 'Витамины', icon: '💊' },
  other: { label: 'Прочее', icon: '📋' },
};

// Common blood test parameters (for quick-add)
const COMMON_PARAMS = {
  blood: [
    { name: 'Гемоглобин', unit: 'г/л', refLow: 120, refHigh: 160 },
    { name: 'Эритроциты', unit: '×10¹²/л', refLow: 3.8, refHigh: 5.1 },
    { name: 'Лейкоциты', unit: '×10⁹/л', refLow: 4.0, refHigh: 9.0 },
    { name: 'Тромбоциты', unit: '×10⁹/л', refLow: 150, refHigh: 400 },
    { name: 'СОЭ', unit: 'мм/ч', refLow: 2, refHigh: 15 },
    { name: 'Гематокрит', unit: '%', refLow: 36, refHigh: 48 },
  ],
  biochem: [
    { name: 'Глюкоза', unit: 'ммоль/л', refLow: 3.9, refHigh: 6.1 },
    { name: 'Холестерин общий', unit: 'ммоль/л', refLow: 0, refHigh: 5.2 },
    { name: 'АЛТ', unit: 'Ед/л', refLow: 0, refHigh: 40 },
    { name: 'АСТ', unit: 'Ед/л', refLow: 0, refHigh: 40 },
    { name: 'Билирубин общий', unit: 'мкмоль/л', refLow: 0, refHigh: 20.5 },
    { name: 'Мочевина', unit: 'ммоль/л', refLow: 2.5, refHigh: 8.3 },
    { name: 'Креатинин', unit: 'мкмоль/л', refLow: 44, refHigh: 115 },
  ],
  hormones: [
    { name: 'ТТГ', unit: 'мМЕ/л', refLow: 0.4, refHigh: 4.0 },
    { name: 'Т4 свободный', unit: 'пмоль/л', refLow: 9.0, refHigh: 22.0 },
    { name: 'Кортизол', unit: 'нмоль/л', refLow: 138, refHigh: 635 },
    { name: 'Инсулин', unit: 'мкЕд/мл', refLow: 2.0, refHigh: 25.0 },
  ],
  vitamins: [
    { name: 'Витамин D', unit: 'нг/мл', refLow: 30, refHigh: 100 },
    { name: 'Витамин B12', unit: 'пг/мл', refLow: 187, refHigh: 883 },
    { name: 'Железо', unit: 'мкмоль/л', refLow: 9.0, refHigh: 30.4 },
    { name: 'Ферритин', unit: 'нг/мл', refLow: 10, refHigh: 120 },
    { name: 'Фолиевая кислота', unit: 'нг/мл', refLow: 3.1, refHigh: 17.5 },
  ],
};

// ══════════════════════════════════════════════════════
// INIT
// ══════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
  // Set today's date default for date inputs
  document.getElementById('test-date').value = todayStr();

  if (token) {
    try {
      const res = await apiFetch('/api/auth/me');
      currentUser = res;
      enterApp();
    } catch {
      token = null;
      localStorage.removeItem('medlab_token');
    }
  }
});

// ══════════════════════════════════════════════════════
// AUTH
// ══════════════════════════════════════════════════════
function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach((t, i) => t.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register')));
  document.getElementById('login-form').classList.toggle('hidden', tab !== 'login');
  document.getElementById('register-form').classList.toggle('hidden', tab !== 'register');
}

async function login() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  if (!email || !password) return toast('Заполните все поля', 'error');
  const btn = document.getElementById('login-btn');
  btn.disabled = true; btn.innerHTML = '<div class="spinner"></div> Вход...';
  try {
    const data = await apiFetch('/api/auth/login', 'POST', { email, password });
    token = data.token;
    currentUser = data.user;
    localStorage.setItem('medlab_token', token);
    enterApp();
  } catch (e) {
    toast(e.message || 'Неверный логин или пароль', 'error');
    btn.disabled = false; btn.textContent = 'Войти';
  }
}

async function register() {
  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;
  if (!name || !email || !password) return toast('Заполните все поля', 'error');
  if (password.length < 6) return toast('Пароль минимум 6 символов', 'error');
  const btn = document.getElementById('register-btn');
  btn.disabled = true; btn.innerHTML = '<div class="spinner"></div>';
  try {
    const data = await apiFetch('/api/auth/register', 'POST', { name, email, password });
    token = data.token;
    currentUser = data.user;
    localStorage.setItem('medlab_token', token);
    enterApp();
  } catch (e) {
    toast(e.message || 'Ошибка регистрации', 'error');
    btn.disabled = false; btn.textContent = 'Создать аккаунт';
  }
}

function logout() {
  token = null;
  currentUser = null;
  tests = [];
  localStorage.removeItem('medlab_token');
  document.getElementById('auth-screen').classList.remove('hidden');
  document.getElementById('main-app').classList.add('hidden');
}

function enterApp() {
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('main-app').classList.remove('hidden');
  // Set user info
  const initial = (currentUser.name || 'U')[0].toUpperCase();
  document.getElementById('user-avatar').textContent = initial;
  document.getElementById('profile-avatar').textContent = initial;
  document.getElementById('profile-name').textContent = currentUser.name;
  document.getElementById('profile-email').textContent = currentUser.email;
  // Greeting
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Доброе утро' : hour < 18 ? 'Добрый день' : 'Добрый вечер';
  document.getElementById('greeting-text').textContent = `${greet}, ${currentUser.name.split(' ')[0]}! 👋`;
  document.getElementById('greeting-date').textContent = new Intl.DateTimeFormat('ru-RU', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());
  loadTests();
}

// ══════════════════════════════════════════════════════
// TESTS DATA
// ══════════════════════════════════════════════════════
async function loadTests() {
  try {
    tests = await apiFetch('/api/tests');
    renderDashboard();
    renderTestList();
    renderCharts();
  } catch (e) {
    toast('Ошибка загрузки данных', 'error');
  }
}

function getTestStatus(test) {
  if (!test.parameters?.length) return 'normal';
  for (const p of test.parameters) {
    if (p.refHigh !== '' && p.refHigh !== undefined && parseFloat(p.value) > parseFloat(p.refHigh)) return 'danger';
    if (p.refLow !== '' && p.refLow !== undefined && parseFloat(p.value) < parseFloat(p.refLow) && parseFloat(p.refLow) > 0) return 'warning';
  }
  return 'normal';
}

function renderDashboard() {
  const now = new Date();
  const thisMonth = tests.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const outCount = tests.filter(t => getTestStatus(t) !== 'normal').length;
  const okCount = tests.filter(t => getTestStatus(t) === 'normal').length;
  document.getElementById('stat-total').textContent = tests.length;
  document.getElementById('stat-out').textContent = outCount;
  document.getElementById('stat-month').textContent = thisMonth.length;
  document.getElementById('stat-ok').textContent = okCount;

  const recent = tests.slice(0, 3);
  const container = document.getElementById('recent-tests');
  if (!recent.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">🧪</div><div class="empty-title">Пока нет анализов</div><p>Добавьте первый анализ, чтобы начать отслеживать показатели</p><button class="btn btn-primary mt-3" onclick="openAddTest()">Добавить анализ</button></div>`;
  } else {
    container.innerHTML = recent.map(renderTestCard).join('');
  }
}

function renderTestCard(test) {
  const status = getTestStatus(test);
  const cat = CATEGORIES[test.category] || CATEGORIES.other;
  const badgeClass = status === 'danger' ? 'badge-danger' : status === 'warning' ? 'badge-warning' : 'badge-normal';
  const badgeText = status === 'danger' ? '⚠ Отклонение' : status === 'warning' ? '↓ Ниже нормы' : '✓ Норма';
  const params = (test.parameters || []).slice(0, 4);
  const paramPills = params.map(p => {
    let cls = '', dot = 'dot-ok';
    if (p.refHigh !== '' && p.refHigh !== undefined && parseFloat(p.value) > parseFloat(p.refHigh)) { cls = 'out-high'; dot = 'dot-high'; }
    else if (p.refLow !== '' && p.refLow !== undefined && parseFloat(p.value) < parseFloat(p.refLow) && parseFloat(p.refLow) > 0) { cls = 'out-low'; dot = 'dot-low'; }
    return `<div class="param-pill ${cls}"><span class="dot ${dot}"></span>${p.name}: <span class="val">${p.value}</span> <span class="text-muted">${p.unit}</span></div>`;
  }).join('');

  return `<div class="test-card" onclick="showTestDetail('${test.id}')">
    <div class="test-card-header">
      <div>
        <div class="test-card-title">${cat.icon} ${test.name}</div>
        <div class="test-card-date">${formatDate(test.date)}${test.lab ? ' · ' + test.lab : ''}</div>
      </div>
      <span class="test-badge ${badgeClass}">${badgeText}</span>
    </div>
    ${paramPills ? `<div class="param-pills">${paramPills}</div>` : ''}
  </div>`;
}

function renderTestList() {
  const query = (document.getElementById('search-input')?.value || '').toLowerCase();
  let filtered = tests;
  if (currentCategory !== 'all') filtered = filtered.filter(t => t.category === currentCategory);
  if (query) filtered = filtered.filter(t =>
    t.name.toLowerCase().includes(query) ||
    (t.lab || '').toLowerCase().includes(query) ||
    (t.parameters || []).some(p => p.name.toLowerCase().includes(query))
  );
  const container = document.getElementById('all-tests');
  if (!filtered.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-title">Ничего не найдено</div><p>Попробуйте изменить фильтр или добавьте новый анализ</p></div>`;
  } else {
    container.innerHTML = filtered.map(renderTestCard).join('');
  }
}

function filterTests() { renderTestList(); }

function selectCategory(el, cat) {
  document.querySelectorAll('#category-chips .chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  currentCategory = cat;
  renderTestList();
}

// ══════════════════════════════════════════════════════
// CHARTS
// ══════════════════════════════════════════════════════
function renderCharts() {
  const container = document.getElementById('charts-container');
  // Collect all unique parameter names that appear in multiple tests
  const paramMap = {};
  for (const test of tests) {
    for (const p of (test.parameters || [])) {
      if (!paramMap[p.name]) paramMap[p.name] = [];
      paramMap[p.name].push({ date: test.date, value: parseFloat(p.value), unit: p.unit, refLow: parseFloat(p.refLow) || null, refHigh: parseFloat(p.refHigh) || null });
    }
  }
  // Only show params with 2+ data points
  const trackable = Object.entries(paramMap).filter(([, arr]) => arr.length >= 2).sort((a, b) => b[1].length - a[1].length);

  if (!trackable.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">📈</div><div class="empty-title">Нет данных для графиков</div><p>Добавьте минимум 2 анализа с одинаковыми показателями для отображения динамики</p></div>`;
    return;
  }

  container.innerHTML = trackable.map(([name]) => `<div class="chart-container"><div class="chart-header"><div><div class="chart-title">${name}</div></div></div><canvas id="chart-${slugify(name)}" height="160"></canvas></div>`).join('');

  for (const [name, points] of trackable) {
    const sorted = points.sort((a, b) => new Date(a.date) - new Date(b.date));
    const ctx = document.getElementById('chart-' + slugify(name))?.getContext('2d');
    if (!ctx) continue;

    const refLow = sorted[0].refLow;
    const refHigh = sorted[0].refHigh;
    const colors = sorted.map(p => {
      if (refHigh && p.value > refHigh) return '#EF4444';
      if (refLow && p.value < refLow) return '#F59E0B';
      return '#00C9A7';
    });

    const datasets = [{
      label: name,
      data: sorted.map(p => p.value),
      borderColor: '#00C9A7',
      backgroundColor: 'rgba(0,201,167,0.08)',
      pointBackgroundColor: colors,
      pointBorderColor: colors,
      pointRadius: 5,
      pointHoverRadius: 7,
      tension: 0.3,
      fill: true,
    }];

    if (refHigh) datasets.push({ label: 'Верхняя норма', data: sorted.map(() => refHigh), borderColor: 'rgba(239,68,68,0.4)', borderDash: [4, 4], pointRadius: 0, fill: false });
    if (refLow && refLow > 0) datasets.push({ label: 'Нижняя норма', data: sorted.map(() => refLow), borderColor: 'rgba(245,158,11,0.4)', borderDash: [4, 4], pointRadius: 0, fill: false });

    if (charts[name]) charts[name].destroy();
    charts[name] = new Chart(ctx, {
      type: 'line',
      data: { labels: sorted.map(p => formatDate(p.date)), datasets },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#0C1120',
            borderColor: 'rgba(0,201,167,0.2)',
            borderWidth: 1,
            titleColor: '#F0F4FF',
            bodyColor: '#8B9CC8',
            callbacks: { label: ctx => `${ctx.parsed.y} ${sorted[0].unit}` }
          }
        },
        scales: {
          x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#4A5A80', font: { size: 11 } } },
          y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#4A5A80', font: { size: 11 } } }
        }
      }
    });
  }
}

// ══════════════════════════════════════════════════════
// TEST DETAIL
// ══════════════════════════════════════════════════════
function showTestDetail(id) {
  const test = tests.find(t => t.id === id);
  if (!test) return;
  const cat = CATEGORIES[test.category] || CATEGORIES.other;
  const status = getTestStatus(test);
  const statusText = { normal: '✓ Все в норме', warning: '↓ Есть показатели ниже нормы', danger: '⚠ Есть отклонения от нормы' }[status];
  const badgeClass = { normal: 'badge-normal', warning: 'badge-warning', danger: 'badge-danger' }[status];

  const paramsHTML = (test.parameters || []).map(p => {
    let statusChip = '<span class="status-chip" style="background:rgba(16,185,129,0.1);color:var(--green)">✓ Норма</span>';
    let valColor = 'var(--text-1)';
    const val = parseFloat(p.value);
    const hi = parseFloat(p.refHigh);
    const lo = parseFloat(p.refLow);
    if (p.refHigh !== '' && p.refHigh !== undefined && val > hi) {
      statusChip = '<span class="status-chip" style="background:rgba(239,68,68,0.1);color:var(--red)">↑ Выше нормы</span>';
      valColor = 'var(--red)';
    } else if (p.refLow !== '' && p.refLow !== undefined && val < lo && lo > 0) {
      statusChip = '<span class="status-chip" style="background:rgba(245,158,11,0.1);color:var(--amber)">↓ Ниже нормы</span>';
      valColor = 'var(--amber)';
    }
    const ref = (p.refLow !== '' && p.refHigh !== '') ? `${p.refLow} – ${p.refHigh}` : (p.refHigh !== '' ? `< ${p.refHigh}` : '—');
    return `<tr>
      <td>${p.name}</td>
      <td class="param-val" style="color:${valColor}">${p.value} <span class="text-muted text-xs">${p.unit}</span></td>
      <td class="ref-range">${ref} <span class="text-muted">${p.unit}</span></td>
      <td>${statusChip}</td>
    </tr>`;
  }).join('');

  document.getElementById('detail-content').innerHTML = `
    <div class="flex gap-2" style="align-items:center;justify-content:space-between;margin-bottom:20px">
      <div>
        <div style="font-family:var(--font-display);font-size:20px;font-weight:700">${cat.icon} ${test.name}</div>
        <div class="text-muted text-sm mt-1">${formatDate(test.date)}${test.lab ? ' · ' + test.lab : ''}</div>
      </div>
      <span class="test-badge ${badgeClass}">${statusText}</span>
    </div>

    ${test.parameters?.length ? `<div class="detail-section">
      <div class="detail-section-title">Показатели</div>
      <div style="overflow-x:auto">
        <table class="param-table">
          <thead><tr><th>Показатель</th><th>Значение</th><th>Референс</th><th>Статус</th></tr></thead>
          <tbody>${paramsHTML}</tbody>
        </table>
      </div>
    </div>` : ''}

    ${test.notes ? `<div class="detail-section">
      <div class="detail-section-title">Примечания</div>
      <div class="detail-note">${test.notes}</div>
    </div>` : ''}

    <div class="flex gap-2 mt-4">
      <button class="btn btn-ghost" style="flex:1" onclick="closeOverlay('detail-overlay')">Закрыть</button>
      <button class="btn btn-ghost" style="flex:1" onclick="editTest('${test.id}')">✏️ Редактировать</button>
      <button class="btn btn-danger btn-sm" onclick="deleteTest('${test.id}')">🗑</button>
    </div>`;

  openOverlay('detail-overlay');
}

// ══════════════════════════════════════════════════════
// ADD / EDIT TEST
// ══════════════════════════════════════════════════════
function openAddTest() {
  editingTestId = null;
  document.getElementById('drawer-title').textContent = 'Новый анализ';
  document.getElementById('test-name').value = '';
  document.getElementById('test-date').value = todayStr();
  document.getElementById('test-lab').value = '';
  document.getElementById('test-notes').value = '';
  document.getElementById('test-category').value = 'blood';
  document.getElementById('params-list').innerHTML = '';
  paramRowCount = 0;
  addParamRow();
  openOverlay('add-test-overlay');
}

function editTest(id) {
  closeOverlay('detail-overlay');
  const test = tests.find(t => t.id === id);
  if (!test) return;
  editingTestId = id;
  document.getElementById('drawer-title').textContent = 'Редактировать анализ';
  document.getElementById('test-name').value = test.name;
  document.getElementById('test-date').value = test.date;
  document.getElementById('test-lab').value = test.lab || '';
  document.getElementById('test-notes').value = test.notes || '';
  document.getElementById('test-category').value = test.category;
  document.getElementById('params-list').innerHTML = '';
  paramRowCount = 0;
  if (test.parameters?.length) {
    test.parameters.forEach(p => addParamRow(p));
  } else {
    addParamRow();
  }
  openOverlay('add-test-overlay');
}

function addParamRow(data = {}) {
  const i = paramRowCount++;
  const row = document.createElement('div');
  row.className = 'param-form-row';
  row.id = `param-row-${i}`;
  row.innerHTML = `
    <input type="text" class="form-input" placeholder="Показатель" value="${data.name || ''}" id="p-name-${i}">
    <input type="number" class="form-input" placeholder="0.0" value="${data.value || ''}" id="p-val-${i}" step="any">
    <input type="text" class="form-input" placeholder="г/л" value="${data.unit || ''}" id="p-unit-${i}">
    <input type="text" class="form-input" placeholder="0-100" value="${data.refLow !== undefined ? data.refLow : ''}–${data.refHigh !== undefined ? data.refHigh : ''}" id="p-ref-${i}" title="Норма: нижн–верхн, напр. 120–160">
    <button class="btn btn-ghost btn-icon" onclick="document.getElementById('param-row-${i}').remove()" title="Удалить">✕</button>`;
  document.getElementById('params-list').appendChild(row);
}

async function saveTest() {
  const name = document.getElementById('test-name').value.trim();
  const date = document.getElementById('test-date').value;
  const category = document.getElementById('test-category').value;
  if (!name) return toast('Укажите название анализа', 'error');
  if (!date) return toast('Укажите дату', 'error');

  // Collect parameters
  const parameters = [];
  document.querySelectorAll('#params-list .param-form-row').forEach(row => {
    const id = row.id.split('-').pop();
    const paramName = document.getElementById(`p-name-${id}`)?.value.trim();
    const val = document.getElementById(`p-val-${id}`)?.value;
    const unit = document.getElementById(`p-unit-${id}`)?.value.trim();
    const refRaw = document.getElementById(`p-ref-${id}`)?.value || '';
    if (!paramName || !val) return;
    const refParts = refRaw.split('–').map(s => s.trim());
    parameters.push({
      name: paramName, value: val, unit,
      refLow: refParts[0] || '', refHigh: refParts[1] || ''
    });
  });

  const payload = {
    name,
    date,
    category,
    lab: document.getElementById('test-lab').value.trim(),
    notes: document.getElementById('test-notes').value.trim(),
    parameters,
  };

  const btn = document.getElementById('save-test-btn');
  btn.disabled = true; btn.innerHTML = '<div class="spinner"></div>';

  try {
    if (editingTestId) {
      const updated = await apiFetch(`/api/tests/${editingTestId}`, 'PUT', payload);
      tests = tests.map(t => t.id === editingTestId ? updated : t);
      toast('Анализ обновлён ✓', 'success');
    } else {
      const created = await apiFetch('/api/tests', 'POST', payload);
      tests.unshift(created);
      toast('Анализ добавлен ✓', 'success');
    }
    closeOverlay('add-test-overlay');
    renderDashboard();
    renderTestList();
    renderCharts();
  } catch (e) {
    toast(e.message || 'Ошибка сохранения', 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Сохранить';
  }
}

async function deleteTest(id) {
  if (!confirm('Удалить этот анализ?')) return;
  try {
    await apiFetch(`/api/tests/${id}`, 'DELETE');
    tests = tests.filter(t => t.id !== id);
    closeOverlay('detail-overlay');
    renderDashboard();
    renderTestList();
    renderCharts();
    toast('Анализ удалён', 'success');
  } catch {
    toast('Ошибка удаления', 'error');
  }
}

// ══════════════════════════════════════════════════════
// NAVIGATION
// ══════════════════════════════════════════════════════
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`page-${name}`)?.classList.add('active');
  document.getElementById(`nav-${name}`)?.classList.add('active');
  if (name === 'charts') renderCharts();
}

// ══════════════════════════════════════════════════════
// OVERLAYS
// ══════════════════════════════════════════════════════
function openOverlay(id) { document.getElementById(id).classList.add('open'); }
function closeOverlay(id) { document.getElementById(id).classList.remove('open'); }
function closeOverlayIfBg(e, id) { if (e.target.id === id) closeOverlay(id); }

// ══════════════════════════════════════════════════════
// EXPORT
// ══════════════════════════════════════════════════════
function exportData() {
  const data = JSON.stringify(tests, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `medlab-export-${todayStr()}.json`;
  a.click(); URL.revokeObjectURL(url);
  toast('Данные экспортированы ✓', 'success');
}

// ══════════════════════════════════════════════════════
// API HELPER
// ══════════════════════════════════════════════════════
async function apiFetch(url, method = 'GET', body) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API + url, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Ошибка сети');
  return data;
}

// ══════════════════════════════════════════════════════
// UTILITIES
// ══════════════════════════════════════════════════════
function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${type === 'success' ? '✓' : '✕'}</span> ${msg}`;
  document.getElementById('toasts').appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function todayStr() {
  return new Date().toISOString().split('T')[0];
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  try {
    return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(dateStr));
  } catch { return dateStr; }
}

function slugify(str) {
  return str.toLowerCase().replace(/[^a-zа-я0-9]/gi, '-').replace(/-+/g, '-');
}

// Keyboard shortcuts
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.overlay.open').forEach(o => o.classList.remove('open'));
  }
});
